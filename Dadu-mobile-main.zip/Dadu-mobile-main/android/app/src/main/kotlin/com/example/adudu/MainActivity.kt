package com.example.adudu

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
